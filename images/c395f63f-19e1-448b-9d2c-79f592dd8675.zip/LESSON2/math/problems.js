// // boolean1

// let A = -10;

// let res = A > 0;

// console.log(res);

// boolean2

// let A = 20;

// let res = A % 2 == 1;

// console.log(res);

// boolean3

// let A = 4;
// let B = 5;

// let res = A > 2 && B <= 3;

// console.log(res);

// boolean4

// let A = 4;
// let B = 5;
// let C = 3;

// let res = A <= B && B <= C;

// console.log(res);

// boolean5

// let A = 4;
// let B = 10;

// let res = (A % 2 === 1 && B % 2 === 1) || (A % 2 === 0 && B % 2 === 0);

// let res = (A + B) % 2 === 0;

// console.log(res);

// boolean6

// let A = 10;
// let B = 0;
// let C = -5;

// let res = A > 0 || B > 0 || C > 0;

// console.log(res);

// boolean7

// let abc = 562;

// let a = parseInt(abc / 100);
// let c = abc % 10;
// let b = ((abc - c) / 10) % 10;

// let res = a != b && a != c && b != c;

// console.log(res);

// boolean8

// let a = 5;
// let b = 8;
// let c = 5;

// let res = a == b || b == c || a == c;
// let res = (a == b && a != c) || (b == c && b != a) || (a == c && a != b);

// console.log(res);

// exp1

let A = 3;
let B = 5;
let C = 7;

let Y1 = 1 / Math.pow(A, 2);
let Y2 = Math.pow(B / 10, 2);
let Y3 = Math.sqrt(A + C);

let Y = Y1 - Y2 * Y3;

console.log(Y);
