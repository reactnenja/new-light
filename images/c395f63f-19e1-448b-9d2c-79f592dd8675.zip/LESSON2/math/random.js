// let n = Math.round(Math.random() * 50);
// let n = Math.round(Math.random() * 40) + 30;

let n = Math.round(Math.random() * 50) + 100;

console.log(n);
