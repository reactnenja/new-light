// console.log(Math.round(5.123312));
// console.log(Math.round(10.823312));
// console.log(Math.round(-6.223312));
// console.log(Math.round(-8.923312));
// console.log(Math.round(Math.PI));

// console.log(Math.trunc(12.94933443));
// console.log(Math.trunc(8.99999999999));
// console.log(Math.trunc(7.00031233213));
// console.log(Math.trunc(-5.839823621));

// console.log(Math.ceil(4.63123213));
// console.log(Math.floor(4.63123213));

// console.log(Math.ceil(10.5));
// console.log(Math.floor(10.5));

// console.log(Math.ceil(7.131231232132312));
// console.log(Math.ceil(-5.5892786));

// console.log(Math.floor(7.131231232132312));
// console.log(Math.floor(-5.5892786));

// console.log(Math.sign(3123));
// console.log(Math.sign(645785));
// console.log(Math.sign(0));
// console.log(Math.sign(-3923129832913));

// console.log(Math.pow(5, 3));
// console.log(Math.pow(2, 6));

// console.log(Math.sqrt(9));
// console.log(Math.sqrt(16));

// console.log(Math.abs(12));
// console.log(Math.abs(-12));

// console.log(Math.min(1, 0, 5, 7, 8));
// console.log(Math.max(1, 0, 5, 7, 8));

// console.log(Math.max());
// console.log(Math.min());

// console.log(Math.max() < Math.min());
