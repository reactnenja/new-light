let person = {
  firstName: "Abdulaziz",
  lastName: "Toshpulatov",
  isMarried: false,
  age: 24,
  selected: null,
  test: undefined,
  symbol: Symbol(),
  iq: 9812312321398137892312983n,
  university: {
    name: "TATU",
    year: "2019-2023",
  },
};

console.log(person.firstName);

console.log(person.age);

console.log(person.isMarried);
