// console.log(2 ** 53);

// let n = 9007199254740991;

// let a = 9007199254740992;
// let b = 9007199254740994;

// console.log(a + b);

let bigintA = 9007199254740992n;
let bigintB = 9007199254740994n;
let bigintC = 1789189371289312893129n;

let res = bigintA + bigintB;

console.log(res, typeof res);
console.log(bigintC, typeof bigintC);
