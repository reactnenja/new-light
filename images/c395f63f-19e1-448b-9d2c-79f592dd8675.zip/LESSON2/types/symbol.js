let s1 = Symbol("abdulaziz");
let s2 = Symbol("abdulaziz");

console.log(s1, typeof s1);
console.log(s2, typeof s2);
