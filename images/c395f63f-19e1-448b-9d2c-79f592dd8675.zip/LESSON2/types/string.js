let firstName = "Abdulaziz";

console.log(firstName, typeof firstName);

let lastName = 'Toshpulatov';

console.log(lastName, typeof lastName);

let middleName = `Abdulatif o'g'li`

console.log(middleName, typeof middleName);