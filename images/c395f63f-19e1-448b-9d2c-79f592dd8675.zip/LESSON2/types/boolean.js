let isMarried = false;

console.log(isMarried, typeof isMarried);

let isSingle = true;

console.log(isSingle, typeof isSingle);
