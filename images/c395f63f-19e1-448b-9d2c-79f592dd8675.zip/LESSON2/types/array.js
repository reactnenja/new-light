let arr = [
  1,
  5,
  "abc",
  "",
  null,
  false,
  undefined,
  Symbol(),
  131232313131312321312312n,
];
