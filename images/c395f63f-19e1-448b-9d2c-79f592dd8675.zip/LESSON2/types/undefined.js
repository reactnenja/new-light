let firstName;

console.log(firstName, typeof firstName);
