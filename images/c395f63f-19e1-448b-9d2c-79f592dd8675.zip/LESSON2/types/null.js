let selected = null;

console.log(selected, typeof selected);
