// console.log(Infinity, typeof Infinity);

// console.log(12 / 0);

// console.log(NaN, typeof NaN);

// console.log(0 / 0);

// console.log("abc" / 5);

// console.log(0b10110);

// console.log(0o4762);

// console.log(0xa6b8f);

// console.log(0.68, typeof 0.68); // float

// console.log(0.1 + 0.2); // js bug

// console.log(0.2 + 0.5);

// console.log(12e5); // 12 * 10 ^ 5
// console.log(12e-5); // 12 * 10 ^ (-5)

console.log(5_671_234_783);