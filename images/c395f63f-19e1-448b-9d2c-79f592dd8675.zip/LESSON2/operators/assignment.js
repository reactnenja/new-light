// let a;

// a = 5;

// a = 10;

// console.log(a);

// let groupSize = 10;

// groupSize = groupSize + 5;
// groupSize += 5;

// groupSize -= 3;

// groupSize *= 2;

// groupSize /= 2;

// console.log(groupSize);

let n = 100;

n %= 7; // n = n % 7

console.log(n);

let d = 5;

d **= 4; // d = d ** 4

console.log(d);
