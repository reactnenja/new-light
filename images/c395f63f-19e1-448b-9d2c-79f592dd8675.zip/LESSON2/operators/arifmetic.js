// let res1 = 12 + "5";
// let res2 = 12 + "abc";
// let res3 = 12 + "5" + 100;
// let res4 = 12 + 13 + "14";

// console.log(res1);
// console.log(res2);
// console.log(res3);
// console.log(res4);

// console.log(12 / "3");
// console.log(12 * "3");
// console.log(12 - "3");

// console.log("12" / 3);

// console.log("100" / "5");

// console.log("abc" / 12);
// console.log("abc" / "abc");
