// console.log(true && true && false);
// console.log(true && true && true);
// console.log(false && true && true);

// console.log(true || false || true || true);
// console.log(false || false || false || true);
// console.log(false || false || false || false);

// console.log(!true);
// console.log(!false);

// let res = (true && false) || false || (true && !false);
let res = !(false || (!true && true)) && ((false && !true) || false);

console.log(res);