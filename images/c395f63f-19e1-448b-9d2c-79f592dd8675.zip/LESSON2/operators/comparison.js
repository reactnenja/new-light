// console.log(12 == 12);
// console.log(12 == "12");
// console.log(1 == true);
// console.log(0 == false);

// console.log(12 === 12);
// console.log(12 === "12");
// console.log(1 === true);
// console.log(0 === false);

// console.log(12 != 13);
// console.log(0 != 0);

// console.log(12 !== "12");
// console.log(0 !== false);
// console.log(2 !== 2);

// console.log(12 > 5);
// console.log(12 > 12);
// console.log(5 > 12);

// console.log(10 >= 10);
// console.log(10 >= 11);

// console.log(0 >= false);

// console.log(10 < 15);
// console.log(10 < 9);
// console.log(11 < 11);

// console.log(11 <= 11);
// console.log(11 <= 15);
// console.log(11 <= 9);
